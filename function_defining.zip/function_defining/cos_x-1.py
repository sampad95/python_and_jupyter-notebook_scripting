def sum(x,n):
    """This is cos(x) infinite series"""
    sum=0
    def fact(n):              # function inside a function
        """Factorial function inside cos(x) infinite sum function"""
        fact=1
        for i in range(1,n+1):
            fact=fact*i
        return fact
    print(fact.__doc__)      # prints about the factorial function written inside triple quotes inside the function definition
    for j in range(0,n+1):
        sum=sum+(((-1)**j)*(x**(2*j))/fact(2*j))
    return sum
print(sum.__doc__)               # prints about the sum function written inside triple quotes inside the function definition
x=eval(input('Enter the value of x\n'))
n=eval(input('Enter the value of n\n'))
print(sum(x,n))
