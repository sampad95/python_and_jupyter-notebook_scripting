def f(n):
    return n+((10*n)+n)+((100*n)+(10*n)+n)+((1000*n)+(100*n)+(10*n)+n)
n=eval(input('Enter the integer value of n\n'))
print(f(n))
