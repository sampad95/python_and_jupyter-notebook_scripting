from math import *
x=eval(input('Enter the value of n\n'))
print(factorial(x))
