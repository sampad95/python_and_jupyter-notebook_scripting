def f(x):
    return (x-1)*(x-2)*(x-3)*(x-4)*(x-5)
x=eval(input('Enter the value of x\n'))
print(f(x))
