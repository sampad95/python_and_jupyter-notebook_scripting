def volume(r,h):
    return pi*r**2*h
r=eval(input('Enter the radius\n'))
'\n'
h=eval(input('Enter the height\n'))
print('Volume of the radius=',volume(r,h))
