def rec(n):
    i=0
    for i in list[0,1]:
        i+2=i+(i+1)

