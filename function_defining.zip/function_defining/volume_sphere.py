#def volume(r):
#    return (4/3)*pi*r**2
#r=eval(input('Enter the radius\n'))
#print('Volume of the sphere =',volume(r))

#---------or---------

r=eval(input('Enter the radius\n'))
def volume(r):
    return (4/3)*pi*r**2
print('Volume of the sphere =', volume(r))

